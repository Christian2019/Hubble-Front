import { Component, OnInit, Input } from '@angular/core';
import { EventService } from '../services/event.service';

@Component({
  selector: 'colocar <example> aqui',
  templateUrl: 'html aqui',
  styleUrls: ['css file aqui']
})
export class TodoItemComponent implements OnInit {

  @Input() event: Event;

  constructor() { }

  ngOnInit() {
  }

}
