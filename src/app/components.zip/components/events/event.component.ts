import { Component, OnInit } from '@angular/core';
import { Event } from '../events/models/event';
import { Adress } from '../events/models/adress';
import { EventService } from '../services/event.service';

@Component({
    selector: 'insert selector',
    templateUrl: 'insert template url',
    styleUrls: ['insert styling css']
})

export class EventComponent implements OnInit {

    events: Event[];

    constructor(private eventService: EventService){ }

    ngOnInit() {
        this.eventService.getJson().subscribe(thisEvent => {
            // this.events = thisEvent; 
            // ta dando erro POR QUEEEEE
            // igual ao meu dia a dia
        })
    }


}
